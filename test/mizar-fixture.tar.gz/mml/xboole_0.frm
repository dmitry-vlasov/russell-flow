<?xml version="1.0"?>
<Formats>
 <Format kind="V" nr="1" symbolnr="1" argnr="1"/>
 <Format kind="M" nr="2" symbolnr="2" argnr="0"/>
 <Format kind="M" nr="3" symbolnr="1" argnr="0"/>
 <Format kind="R" nr="4" symbolnr="1" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="5" symbolnr="2" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="6" symbolnr="3" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="7" symbolnr="4" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="8" symbolnr="5" argnr="2" leftargnr="2"/>
 <Format kind="K" nr="9" symbolnr="2" argnr="1" rightsymbolnr="2"/>
 <Format kind="K" nr="10" symbolnr="2" argnr="2" rightsymbolnr="2"/>
 <Format kind="O" nr="11" symbolnr="1" argnr="1" leftargnr="0"/>
 <Format kind="K" nr="12" symbolnr="1" argnr="2" rightsymbolnr="1"/>
 <Priority kind="O" symbolnr="1" value="128"/>
 <Priority kind="O" symbolnr="2" value="128"/>
 <Priority kind="O" symbolnr="3" value="32"/>
 <Priority kind="O" symbolnr="4" value="64"/>
 <Priority kind="O" symbolnr="5" value="32"/>
 <Priority kind="O" symbolnr="6" value="30"/>
 <Priority kind="O" symbolnr="7" value="64"/>
 <Priority kind="O" symbolnr="8" value="64"/>
 <Priority kind="O" symbolnr="9" value="64"/>
 <Priority kind="O" symbolnr="10" value="64"/>
 <Priority kind="O" symbolnr="11" value="64"/>
 <Priority kind="O" symbolnr="12" value="64"/>
 <Priority kind="O" symbolnr="13" value="64"/>
 <Priority kind="O" symbolnr="14" value="16"/>
 <Priority kind="O" symbolnr="15" value="64"/>
 <Priority kind="O" symbolnr="16" value="64"/>
 <Priority kind="O" symbolnr="17" value="64"/>
 <Priority kind="O" symbolnr="18" value="64"/>
 <Priority kind="O" symbolnr="19" value="64"/>
 <Priority kind="O" symbolnr="20" value="64"/>
 <Priority kind="O" symbolnr="21" value="64"/>
 <Priority kind="O" symbolnr="22" value="64"/>
</Formats>
