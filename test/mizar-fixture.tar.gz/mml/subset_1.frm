<?xml version="1.0"?>
<Formats>
 <Format kind="V" nr="1" symbolnr="1" argnr="1"/>
 <Format kind="M" nr="2" symbolnr="2" argnr="0"/>
 <Format kind="M" nr="3" symbolnr="1" argnr="0"/>
 <Format kind="R" nr="4" symbolnr="1" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="5" symbolnr="2" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="6" symbolnr="3" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="7" symbolnr="9" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="8" symbolnr="10" argnr="2" leftargnr="2"/>
 <Format kind="K" nr="9" symbolnr="2" argnr="1" rightsymbolnr="2"/>
 <Format kind="K" nr="10" symbolnr="2" argnr="2" rightsymbolnr="2"/>
 <Format kind="O" nr="11" symbolnr="7" argnr="1" leftargnr="0"/>
 <Format kind="K" nr="12" symbolnr="1" argnr="2" rightsymbolnr="1"/>
 <Format kind="V" nr="13" symbolnr="3" argnr="1"/>
 <Format kind="R" nr="14" symbolnr="5" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="15" symbolnr="6" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="16" symbolnr="7" argnr="2" leftargnr="2"/>
 <Format kind="R" nr="17" symbolnr="8" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="18" symbolnr="2" argnr="0" leftargnr="0"/>
 <Format kind="O" nr="19" symbolnr="3" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="20" symbolnr="4" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="21" symbolnr="5" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="22" symbolnr="6" argnr="2" leftargnr="1"/>
 <Format kind="K" nr="23" symbolnr="2" argnr="3" rightsymbolnr="2"/>
 <Format kind="K" nr="24" symbolnr="2" argnr="4" rightsymbolnr="2"/>
 <Format kind="K" nr="25" symbolnr="2" argnr="5" rightsymbolnr="2"/>
 <Format kind="K" nr="26" symbolnr="2" argnr="6" rightsymbolnr="2"/>
 <Format kind="K" nr="27" symbolnr="2" argnr="7" rightsymbolnr="2"/>
 <Format kind="K" nr="28" symbolnr="2" argnr="8" rightsymbolnr="2"/>
 <Format kind="K" nr="29" symbolnr="2" argnr="9" rightsymbolnr="2"/>
 <Format kind="K" nr="30" symbolnr="2" argnr="10" rightsymbolnr="2"/>
 <Format kind="V" nr="31" symbolnr="2" argnr="1"/>
 <Format kind="R" nr="32" symbolnr="4" argnr="3" leftargnr="3"/>
 <Format kind="R" nr="33" symbolnr="4" argnr="4" leftargnr="4"/>
 <Format kind="R" nr="34" symbolnr="4" argnr="5" leftargnr="5"/>
 <Format kind="R" nr="35" symbolnr="4" argnr="6" leftargnr="6"/>
 <Format kind="R" nr="36" symbolnr="4" argnr="7" leftargnr="7"/>
 <Format kind="O" nr="37" symbolnr="1" argnr="1" leftargnr="0"/>
 <Format kind="K" nr="38" symbolnr="4" argnr="2" rightsymbolnr="4"/>
 <Format kind="K" nr="39" symbolnr="4" argnr="3" rightsymbolnr="4"/>
 <Format kind="K" nr="40" symbolnr="4" argnr="4" rightsymbolnr="4"/>
 <Priority kind="K" symbolnr="4" value="64"/>
 <Priority kind="L" symbolnr="4" value="64"/>
 <Priority kind="O" symbolnr="1" value="128"/>
 <Priority kind="O" symbolnr="2" value="128"/>
 <Priority kind="O" symbolnr="3" value="32"/>
 <Priority kind="O" symbolnr="4" value="64"/>
 <Priority kind="O" symbolnr="5" value="32"/>
 <Priority kind="O" symbolnr="6" value="30"/>
 <Priority kind="O" symbolnr="7" value="128"/>
 <Priority kind="O" symbolnr="8" value="128"/>
 <Priority kind="O" symbolnr="9" value="150"/>
 <Priority kind="O" symbolnr="10" value="64"/>
 <Priority kind="O" symbolnr="11" value="64"/>
 <Priority kind="O" symbolnr="12" value="64"/>
 <Priority kind="O" symbolnr="13" value="64"/>
 <Priority kind="O" symbolnr="14" value="64"/>
 <Priority kind="O" symbolnr="15" value="64"/>
 <Priority kind="O" symbolnr="16" value="64"/>
 <Priority kind="O" symbolnr="17" value="64"/>
 <Priority kind="O" symbolnr="18" value="64"/>
</Formats>
