<?xml version="1.0"?>
<Vocabularies>
 <Vocabulary>
  <ArticleID name="HIDDEN"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="3"/>
  <SymbolCount kind="L" nr="3"/>
  <SymbolCount kind="M" nr="2"/>
  <SymbolCount kind="O" nr="0"/>
  <SymbolCount kind="R" nr="3"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="1"/>
 </Vocabulary>
 <Vocabulary>
  <ArticleID name="ZFMISC_1"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="1"/>
  <SymbolCount kind="L" nr="1"/>
  <SymbolCount kind="M" nr="0"/>
  <SymbolCount kind="O" nr="1"/>
  <SymbolCount kind="R" nr="1"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="1"/>
 </Vocabulary>
 <Vocabulary>
  <ArticleID name="XBOOLE_0"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="0"/>
  <SymbolCount kind="L" nr="0"/>
  <SymbolCount kind="M" nr="0"/>
  <SymbolCount kind="O" nr="5"/>
  <SymbolCount kind="R" nr="4"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="1"/>
 </Vocabulary>
 <Vocabulary>
  <ArticleID name="TARSKI"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="0"/>
  <SymbolCount kind="L" nr="0"/>
  <SymbolCount kind="M" nr="0"/>
  <SymbolCount kind="O" nr="1"/>
  <SymbolCount kind="R" nr="2"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="0"/>
 </Vocabulary>
 <Vocabulary>
  <ArticleID name="SUBSET_1"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="0"/>
  <SymbolCount kind="L" nr="0"/>
  <SymbolCount kind="M" nr="2"/>
  <SymbolCount kind="O" nr="3"/>
  <SymbolCount kind="R" nr="0"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="1"/>
 </Vocabulary>
 <Vocabulary>
  <ArticleID name="FUNCT_7"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="0"/>
  <SymbolCount kind="L" nr="0"/>
  <SymbolCount kind="M" nr="1"/>
  <SymbolCount kind="O" nr="8"/>
  <SymbolCount kind="R" nr="1"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="1"/>
 </Vocabulary>
</Vocabularies>
