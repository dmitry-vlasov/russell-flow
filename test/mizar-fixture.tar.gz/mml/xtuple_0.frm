<?xml version="1.0"?>
<Formats>
 <Format kind="V" nr="1" symbolnr="1" argnr="1"/>
 <Format kind="M" nr="2" symbolnr="2" argnr="0"/>
 <Format kind="M" nr="3" symbolnr="1" argnr="0"/>
 <Format kind="R" nr="4" symbolnr="1" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="5" symbolnr="2" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="6" symbolnr="3" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="7" symbolnr="5" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="8" symbolnr="6" argnr="2" leftargnr="2"/>
 <Format kind="K" nr="9" symbolnr="2" argnr="1" rightsymbolnr="2"/>
 <Format kind="K" nr="10" symbolnr="2" argnr="2" rightsymbolnr="2"/>
 <Format kind="O" nr="11" symbolnr="57" argnr="1" leftargnr="0"/>
 <Format kind="K" nr="12" symbolnr="1" argnr="2" rightsymbolnr="1"/>
 <Format kind="V" nr="13" symbolnr="13" argnr="1"/>
 <Format kind="R" nr="14" symbolnr="7" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="15" symbolnr="8" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="16" symbolnr="9" argnr="2" leftargnr="2"/>
 <Format kind="R" nr="17" symbolnr="10" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="18" symbolnr="58" argnr="0" leftargnr="0"/>
 <Format kind="O" nr="19" symbolnr="59" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="20" symbolnr="60" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="21" symbolnr="61" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="22" symbolnr="62" argnr="2" leftargnr="1"/>
 <Priority kind="O" symbolnr="1" value="255"/>
 <Priority kind="O" symbolnr="2" value="255"/>
 <Priority kind="O" symbolnr="3" value="255"/>
 <Priority kind="O" symbolnr="4" value="255"/>
 <Priority kind="O" symbolnr="5" value="128"/>
 <Priority kind="O" symbolnr="6" value="128"/>
 <Priority kind="O" symbolnr="7" value="255"/>
 <Priority kind="O" symbolnr="8" value="255"/>
 <Priority kind="O" symbolnr="9" value="255"/>
 <Priority kind="O" symbolnr="10" value="255"/>
 <Priority kind="O" symbolnr="11" value="64"/>
 <Priority kind="O" symbolnr="12" value="64"/>
 <Priority kind="O" symbolnr="13" value="64"/>
 <Priority kind="O" symbolnr="14" value="64"/>
 <Priority kind="O" symbolnr="15" value="64"/>
 <Priority kind="O" symbolnr="16" value="64"/>
 <Priority kind="O" symbolnr="17" value="64"/>
 <Priority kind="O" symbolnr="18" value="64"/>
 <Priority kind="O" symbolnr="19" value="64"/>
 <Priority kind="O" symbolnr="20" value="64"/>
 <Priority kind="O" symbolnr="21" value="64"/>
 <Priority kind="O" symbolnr="22" value="64"/>
 <Priority kind="O" symbolnr="23" value="64"/>
 <Priority kind="O" symbolnr="24" value="64"/>
 <Priority kind="O" symbolnr="25" value="64"/>
 <Priority kind="O" symbolnr="26" value="64"/>
 <Priority kind="O" symbolnr="27" value="64"/>
 <Priority kind="O" symbolnr="28" value="64"/>
 <Priority kind="O" symbolnr="29" value="64"/>
 <Priority kind="O" symbolnr="30" value="64"/>
 <Priority kind="O" symbolnr="31" value="64"/>
 <Priority kind="O" symbolnr="32" value="64"/>
 <Priority kind="O" symbolnr="33" value="64"/>
 <Priority kind="O" symbolnr="34" value="64"/>
 <Priority kind="O" symbolnr="35" value="64"/>
 <Priority kind="O" symbolnr="36" value="64"/>
 <Priority kind="O" symbolnr="37" value="64"/>
 <Priority kind="O" symbolnr="38" value="64"/>
 <Priority kind="O" symbolnr="39" value="64"/>
 <Priority kind="O" symbolnr="40" value="64"/>
 <Priority kind="O" symbolnr="41" value="64"/>
 <Priority kind="O" symbolnr="42" value="64"/>
 <Priority kind="O" symbolnr="43" value="128"/>
 <Priority kind="O" symbolnr="44" value="128"/>
 <Priority kind="O" symbolnr="45" value="128"/>
 <Priority kind="O" symbolnr="46" value="128"/>
 <Priority kind="O" symbolnr="47" value="128"/>
 <Priority kind="O" symbolnr="48" value="128"/>
 <Priority kind="O" symbolnr="49" value="64"/>
 <Priority kind="O" symbolnr="50" value="128"/>
 <Priority kind="O" symbolnr="51" value="100"/>
 <Priority kind="O" symbolnr="52" value="100"/>
 <Priority kind="O" symbolnr="53" value="100"/>
 <Priority kind="O" symbolnr="54" value="128"/>
 <Priority kind="O" symbolnr="55" value="128"/>
 <Priority kind="O" symbolnr="56" value="64"/>
 <Priority kind="O" symbolnr="57" value="128"/>
 <Priority kind="O" symbolnr="58" value="128"/>
 <Priority kind="O" symbolnr="59" value="32"/>
 <Priority kind="O" symbolnr="60" value="64"/>
 <Priority kind="O" symbolnr="61" value="32"/>
 <Priority kind="O" symbolnr="62" value="30"/>
</Formats>
