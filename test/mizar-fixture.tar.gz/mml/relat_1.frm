<?xml version="1.0"?>
<Formats>
 <Format kind="V" nr="1" symbolnr="1" argnr="1"/>
 <Format kind="M" nr="2" symbolnr="2" argnr="0"/>
 <Format kind="M" nr="3" symbolnr="1" argnr="0"/>
 <Format kind="R" nr="4" symbolnr="1" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="5" symbolnr="2" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="6" symbolnr="3" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="7" symbolnr="8" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="8" symbolnr="9" argnr="2" leftargnr="2"/>
 <Format kind="K" nr="9" symbolnr="2" argnr="1" rightsymbolnr="2"/>
 <Format kind="K" nr="10" symbolnr="2" argnr="2" rightsymbolnr="2"/>
 <Format kind="O" nr="11" symbolnr="6" argnr="1" leftargnr="0"/>
 <Format kind="K" nr="12" symbolnr="1" argnr="2" rightsymbolnr="1"/>
 <Format kind="V" nr="13" symbolnr="2" argnr="1"/>
 <Format kind="R" nr="14" symbolnr="4" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="15" symbolnr="5" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="16" symbolnr="6" argnr="2" leftargnr="2"/>
 <Format kind="R" nr="17" symbolnr="7" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="18" symbolnr="1" argnr="0" leftargnr="0"/>
 <Format kind="O" nr="19" symbolnr="2" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="20" symbolnr="3" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="21" symbolnr="4" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="22" symbolnr="5" argnr="2" leftargnr="1"/>
 <Format kind="V" nr="23" symbolnr="3" argnr="1"/>
 <Format kind="R" nr="24" symbolnr="10" argnr="3" leftargnr="3"/>
 <Format kind="R" nr="25" symbolnr="10" argnr="4" leftargnr="4"/>
 <Format kind="R" nr="26" symbolnr="10" argnr="5" leftargnr="5"/>
 <Format kind="R" nr="27" symbolnr="10" argnr="6" leftargnr="6"/>
 <Format kind="R" nr="28" symbolnr="10" argnr="7" leftargnr="7"/>
 <Format kind="O" nr="29" symbolnr="7" argnr="1" leftargnr="0"/>
 <Format kind="K" nr="30" symbolnr="4" argnr="2" rightsymbolnr="4"/>
 <Format kind="K" nr="31" symbolnr="4" argnr="3" rightsymbolnr="4"/>
 <Format kind="K" nr="32" symbolnr="4" argnr="4" rightsymbolnr="4"/>
 <Format kind="K" nr="33" symbolnr="1" argnr="3" rightsymbolnr="1"/>
 <Format kind="K" nr="34" symbolnr="1" argnr="4" rightsymbolnr="1"/>
 <Format kind="O" nr="35" symbolnr="11" argnr="1" leftargnr="0"/>
 <Format kind="O" nr="36" symbolnr="13" argnr="1" leftargnr="0"/>
 <Format kind="M" nr="37" symbolnr="3" argnr="1"/>
 <Format kind="M" nr="38" symbolnr="4" argnr="1"/>
 <Format kind="V" nr="39" symbolnr="4" argnr="1"/>
 <Format kind="O" nr="40" symbolnr="1" argnr="1" leftargnr="0"/>
 <Format kind="O" nr="41" symbolnr="8" argnr="1" leftargnr="0"/>
 <Format kind="O" nr="42" symbolnr="9" argnr="1" leftargnr="1"/>
 <Priority kind="K" symbolnr="4" value="64"/>
 <Priority kind="L" symbolnr="4" value="64"/>
 <Priority kind="O" symbolnr="1" value="128"/>
 <Priority kind="O" symbolnr="2" value="32"/>
 <Priority kind="O" symbolnr="3" value="64"/>
 <Priority kind="O" symbolnr="4" value="32"/>
 <Priority kind="O" symbolnr="5" value="30"/>
 <Priority kind="O" symbolnr="6" value="128"/>
 <Priority kind="O" symbolnr="7" value="128"/>
 <Priority kind="O" symbolnr="8" value="128"/>
 <Priority kind="O" symbolnr="9" value="150"/>
 <Priority kind="O" symbolnr="10" value="64"/>
 <Priority kind="O" symbolnr="11" value="128"/>
 <Priority kind="O" symbolnr="12" value="128"/>
 <Priority kind="O" symbolnr="13" value="128"/>
 <Priority kind="O" symbolnr="14" value="128"/>
 <Priority kind="O" symbolnr="15" value="128"/>
 <Priority kind="O" symbolnr="16" value="128"/>
 <Priority kind="O" symbolnr="17" value="64"/>
 <Priority kind="O" symbolnr="18" value="128"/>
 <Priority kind="O" symbolnr="19" value="100"/>
 <Priority kind="O" symbolnr="20" value="100"/>
 <Priority kind="O" symbolnr="21" value="100"/>
 <Priority kind="O" symbolnr="22" value="128"/>
 <Priority kind="O" symbolnr="23" value="128"/>
 <Priority kind="O" symbolnr="24" value="64"/>
 <Priority kind="O" symbolnr="25" value="64"/>
 <Priority kind="O" symbolnr="26" value="64"/>
 <Priority kind="O" symbolnr="27" value="64"/>
</Formats>
