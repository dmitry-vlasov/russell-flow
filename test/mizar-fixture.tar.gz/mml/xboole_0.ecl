<?xml version="1.0"?>
<?xml-stylesheet type="text/xml" href="file:///usr/local/share/mizar/miz.xml"?>
<Registrations aid="XBOOLE_0" mizfiles="/usr/local/share/mizar/">
</Registrations>
