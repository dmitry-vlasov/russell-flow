<?xml version="1.0"?>
<Vocabularies>
 <Vocabulary>
  <ArticleID name="HIDDEN"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="3"/>
  <SymbolCount kind="L" nr="3"/>
  <SymbolCount kind="M" nr="2"/>
  <SymbolCount kind="O" nr="0"/>
  <SymbolCount kind="R" nr="3"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="1"/>
 </Vocabulary>
 <Vocabulary>
  <ArticleID name="MCART_1"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="0"/>
  <SymbolCount kind="L" nr="0"/>
  <SymbolCount kind="M" nr="0"/>
  <SymbolCount kind="O" nr="10"/>
  <SymbolCount kind="R" nr="0"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="0"/>
 </Vocabulary>
 <Vocabulary>
  <ArticleID name="RECDEF_2"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="0"/>
  <SymbolCount kind="L" nr="0"/>
  <SymbolCount kind="M" nr="0"/>
  <SymbolCount kind="O" nr="12"/>
  <SymbolCount kind="R" nr="0"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="0"/>
 </Vocabulary>
 <Vocabulary>
  <ArticleID name="XTUPLE_0"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="0"/>
  <SymbolCount kind="L" nr="0"/>
  <SymbolCount kind="M" nr="0"/>
  <SymbolCount kind="O" nr="7"/>
  <SymbolCount kind="R" nr="0"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="2"/>
 </Vocabulary>
 <Vocabulary>
  <ArticleID name="FACIRC_1"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="0"/>
  <SymbolCount kind="L" nr="0"/>
  <SymbolCount kind="M" nr="0"/>
  <SymbolCount kind="O" nr="13"/>
  <SymbolCount kind="R" nr="1"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="4"/>
 </Vocabulary>
 <Vocabulary>
  <ArticleID name="RELAT_1"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="0"/>
  <SymbolCount kind="L" nr="0"/>
  <SymbolCount kind="M" nr="1"/>
  <SymbolCount kind="O" nr="14"/>
  <SymbolCount kind="R" nr="0"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="5"/>
 </Vocabulary>
 <Vocabulary>
  <ArticleID name="TARSKI"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="0"/>
  <SymbolCount kind="L" nr="0"/>
  <SymbolCount kind="M" nr="0"/>
  <SymbolCount kind="O" nr="1"/>
  <SymbolCount kind="R" nr="2"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="0"/>
 </Vocabulary>
 <Vocabulary>
  <ArticleID name="XBOOLE_0"/>
  <SymbolCount kind="G" nr="0"/>
  <SymbolCount kind="K" nr="0"/>
  <SymbolCount kind="L" nr="0"/>
  <SymbolCount kind="M" nr="0"/>
  <SymbolCount kind="O" nr="5"/>
  <SymbolCount kind="R" nr="4"/>
  <SymbolCount kind="U" nr="0"/>
  <SymbolCount kind="V" nr="1"/>
 </Vocabulary>
</Vocabularies>
