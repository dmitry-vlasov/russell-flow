<?xml version="1.0"?>
<?xml-stylesheet type="text/xml" href="file:///usr/local/share/mizar/miz.xml"?>
<Registrations aid="RELAT_1" mizfiles="/usr/local/share/mizar/">
<RCluster aid="XBOOLE_0" nr="1">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="1"/>
</Cluster>
</RCluster>
<RCluster aid="XBOOLE_0" nr="2">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="1" value="false"/>
</Cluster>
</RCluster>
<RCluster aid="ZFMISC_1" nr="1">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="1" value="false"/>
<Adjective nr="2"/>
</Cluster>
</RCluster>
<RCluster aid="ZFMISC_1" nr="2">
<ArgTypes/>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="2" value="false"/>
</Cluster>
</RCluster>
<RCluster aid="XTUPLE_0" nr="1">
<ArgTypes/>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="4"/>
</Cluster>
</RCluster>
<RCluster aid="XTUPLE_0" nr="2">
<ArgTypes/>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="5"/>
</Cluster>
</RCluster>
<RCluster aid="XTUPLE_0" nr="3">
<ArgTypes/>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="6"/>
</Cluster>
</RCluster>
<FCluster aid="XBOOLE_0" nr="1">
<ArgTypes/>
<Func kind="K" nr="5"/>
<Cluster>
<Adjective nr="1"/>
</Cluster>
</FCluster>
<FCluster aid="XBOOLE_0" nr="2">
<ArgTypes>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="1">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="1" value="false"/>
</Cluster>
</FCluster>
<FCluster aid="XBOOLE_0" nr="3">
<ArgTypes>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="2">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="1" value="false"/>
</Cluster>
</FCluster>
<FCluster aid="XBOOLE_0" nr="4">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="1" value="false"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="6">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="1" value="false"/>
</Cluster>
</FCluster>
<FCluster aid="XBOOLE_0" nr="5">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="1" value="false"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="6">
<LocusVar nr="2"/>
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="1" value="false"/>
</Cluster>
</FCluster>
<FCluster aid="ZFMISC_1" nr="1">
<ArgTypes>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="1">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="2"/>
</Cluster>
</FCluster>
<FCluster aid="ZFMISC_1" nr="2">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="1"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="11">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="1"/>
</Cluster>
</FCluster>
<FCluster aid="ZFMISC_1" nr="3">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="1"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="11">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="1"/>
</Cluster>
</FCluster>
<FCluster aid="ZFMISC_1" nr="4">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="2"/>
</Cluster>
</Typ>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="2"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="11">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="2"/>
</Cluster>
</FCluster>
<FCluster aid="XTUPLE_0" nr="1">
<ArgTypes>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="4">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
</Func>
<Cluster>
<Adjective nr="4"/>
</Cluster>
</FCluster>
<FCluster aid="XTUPLE_0" nr="2">
<ArgTypes>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="26">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
<LocusVar nr="3"/>
</Func>
<Cluster>
<Adjective nr="5"/>
</Cluster>
</FCluster>
<FCluster aid="XTUPLE_0" nr="3">
<ArgTypes>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
</ArgTypes>
<Func kind="K" nr="29">
<LocusVar nr="1"/>
<LocusVar nr="2"/>
<LocusVar nr="3"/>
<LocusVar nr="4"/>
</Func>
<Cluster>
<Adjective nr="6"/>
</Cluster>
</FCluster>
<FCluster aid="XTUPLE_0" nr="4">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="1"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="32">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="1"/>
</Cluster>
</FCluster>
<FCluster aid="XTUPLE_0" nr="5">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="1"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="33">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="1"/>
</Cluster>
</FCluster>
<FCluster aid="XTUPLE_0" nr="6">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="1"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="34">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="1"/>
</Cluster>
</FCluster>
<FCluster aid="XTUPLE_0" nr="7">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="1"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="35">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="1"/>
</Cluster>
</FCluster>
<FCluster aid="XTUPLE_0" nr="8">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="1"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="36">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="1"/>
</Cluster>
</FCluster>
<FCluster aid="XTUPLE_0" nr="9">
<ArgTypes>
<Typ kind="M" nr="2">
<Cluster>
<Adjective nr="1"/>
</Cluster>
</Typ>
</ArgTypes>
<Func kind="K" nr="37">
<LocusVar nr="1"/>
</Func>
<Cluster>
<Adjective nr="1"/>
</Cluster>
</FCluster>
<CCluster aid="ZFMISC_1" nr="1">
<ArgTypes/>
<Cluster>
<Adjective nr="1"/>
</Cluster>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="2"/>
</Cluster>
</CCluster>
<CCluster aid="ZFMISC_1" nr="2">
<ArgTypes/>
<Cluster>
<Adjective nr="2" value="false"/>
</Cluster>
<Typ kind="M" nr="2">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="1" value="false"/>
</Cluster>
</CCluster>
<CCluster aid="XTUPLE_0" nr="1">
<ArgTypes/>
<Cluster>
<Adjective nr="5"/>
</Cluster>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="4"/>
</Cluster>
</CCluster>
<CCluster aid="XTUPLE_0" nr="2">
<ArgTypes/>
<Cluster>
<Adjective nr="6"/>
</Cluster>
<Typ kind="M" nr="1">
<Cluster/>
</Typ>
<Cluster>
<Adjective nr="5"/>
</Cluster>
</CCluster>
</Registrations>
