<?xml version="1.0"?>
<Formats>
 <Format kind="V" nr="1" symbolnr="1" argnr="1"/>
 <Format kind="M" nr="2" symbolnr="2" argnr="0"/>
 <Format kind="M" nr="3" symbolnr="1" argnr="0"/>
 <Format kind="R" nr="4" symbolnr="1" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="5" symbolnr="2" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="6" symbolnr="3" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="7" symbolnr="4" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="8" symbolnr="5" argnr="2" leftargnr="2"/>
 <Format kind="K" nr="9" symbolnr="2" argnr="1" rightsymbolnr="2"/>
 <Format kind="K" nr="10" symbolnr="2" argnr="2" rightsymbolnr="2"/>
 <Format kind="O" nr="11" symbolnr="1" argnr="1" leftargnr="0"/>
 <Format kind="K" nr="12" symbolnr="1" argnr="2" rightsymbolnr="1"/>
 <Format kind="V" nr="13" symbolnr="2" argnr="1"/>
 <Format kind="R" nr="14" symbolnr="6" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="15" symbolnr="7" argnr="2" leftargnr="1"/>
 <Format kind="R" nr="16" symbolnr="8" argnr="2" leftargnr="2"/>
 <Format kind="R" nr="17" symbolnr="9" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="18" symbolnr="2" argnr="0" leftargnr="0"/>
 <Format kind="O" nr="19" symbolnr="3" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="20" symbolnr="4" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="21" symbolnr="5" argnr="2" leftargnr="1"/>
 <Format kind="O" nr="22" symbolnr="6" argnr="2" leftargnr="1"/>
 <Priority kind="O" symbolnr="1" value="128"/>
 <Priority kind="O" symbolnr="2" value="128"/>
 <Priority kind="O" symbolnr="3" value="32"/>
 <Priority kind="O" symbolnr="4" value="64"/>
 <Priority kind="O" symbolnr="5" value="32"/>
 <Priority kind="O" symbolnr="6" value="30"/>
</Formats>
